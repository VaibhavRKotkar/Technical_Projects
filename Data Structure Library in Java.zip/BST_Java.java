// Binary search tree using Specific programming

import java.lang.*;
import java.util.*;

class node
{
   public int data;
   public node lchild;
   public node rchild;

}

class BST
{
    public node Head;
    public int Count;
    public int iCount;

    public BST()
    {
        this.Head = null;
        this.Count = 0;
    }

    public void Insert(int iNo)
    {
        node newn = new node();
        node temp = Head;
        newn.data = iNo;
        newn.lchild = null;
        newn.rchild = null;

        if(Head == null)
        {
            Head = newn;
        }
       else
    {
            while(true)
            {
                    if(iNo > temp.data)        // R
                    {
                            if(temp.rchild == null)
                            {
                                temp.rchild = newn;
                                break;
                            }
                            temp = temp.rchild;
                    }
                    else if(iNo < temp.data)   // L
                    {
                             if(temp.lchild == null)
                            {
                                temp.lchild = newn;
                                break;
                            }
                            temp = temp.lchild;
                    }
                    else if(iNo == temp.data)  // Duplicate
                    {
                        newn = null;
                        System.out.println("Data is already there in BST");
                        break;
                    }
            }
    }
    Count++;
    }

    public void Inorder()
    {
        Inorder(Head);
    }

   public void Inorder(node Head)
    {
        if(Head == null)
        {
            return;
        }
        Inorder(Head.lchild);
        System.out.print("|"+Head.data + "|->");
        Inorder(Head.rchild);
    }

    public void Preorder()
    {
        Preorder(Head);
    }
    public void Preorder(node Head)
    {
        if(Head == null)
        {
            return;
        }
        System.out.print("|"+Head.data + "|->");
        Preorder(Head.lchild);
        Preorder(Head.rchild);
    }

    public void Postorder()
    {
        Postorder(Head);
    }

   public void Postorder(node Head)
    {
        if(Head == null)
        {
            return;
        }
        Postorder(Head.lchild);
        Postorder(Head.rchild);
        System.out.print("|"+Head.data + "|->");
    }

// Search in the tree.

   public void Search(int iNo)
    {
       node temp = Head;

        while(temp != null)
        {
            if(temp.data == iNo)
            {
                break;
            }
            else if(iNo > temp.data)
            {
                temp = temp.rchild;
            }
            else if(iNo < temp.data)
            {
                temp = temp.lchild;
            }
        }
        if(temp == null)
        {
            System.out.println("\nThe Element "+ iNo +" is not present in tree.");
        }
        else
        {
            System.out.println("\nThe Element "+ iNo +" is present in tree.\n");
        }
    }

  public int CountNode()
    {
       return Count;
    }

  public int CountLeafNode()
    {
        int iCnt = CountLeafNode(Head);
        return iCnt;
    }

  public int CountLeafNode(node Head)
    {
        if(Head != null)
        {
            if((Head.lchild == null) && (Head.rchild == null))
            {
                iCount++;
            }
            CountLeafNode(Head.lchild);
            CountLeafNode(Head.rchild);
        }
       return iCount;
    }

    public void DisplayLeafNode()
    {
        DisplayLeafNode(Head);
    }

  public void DisplayLeafNode(node Head)
    {
        if(Head != null)
        {
            if((Head.lchild == null) && (Head.rchild == null))
            {
                 System.out.print("|"+Head.data + "|");
            }
            DisplayLeafNode(Head.lchild);
            DisplayLeafNode(Head.rchild);
        }
    }
  }

class BST_Java
{
    public static void main(String arg[])
    {
        BST obj1 = new BST();

        obj1.Insert(11);
        obj1.Insert(21);
        obj1.Insert(13);
        obj1.Insert(14);
        obj1.Insert(12);
        obj1.Insert(4);
        obj1.Insert(10);
        System.out.print("\nInordered data:\n");
        obj1.Inorder();
        System.out.print("\nPreorder data:\n");
        obj1.Preorder();
        System.out.print("\nPostorder data:\n");
        obj1.Postorder();

        obj1.Search(0);
        obj1.Search(14);

        System.out.println("Total number of Nodes in tree are :"+ obj1.CountNode());
        System.out.println("Total number of Leaf Nodes in tree are :"+ obj1.CountLeafNode());

        System.out.print("\nLeaf Nodes are:\n");
        System.out.print("\nLeaf Nodes are:\n");
        obj1.DisplayLeafNode();

    }
 }