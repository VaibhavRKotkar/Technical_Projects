// Doubly circular linkedlist in Java.

import java.lang.*;
import java.util.*;

class node
{
   public int data;
   public node next;
   public node prev;      // reference concept
}

class DoublyCLL
{
    public node Head;
    public node Tail;
    public int Count;

   public DoublyCLL()
    {
        Head = null;
        Tail = null;
        Count = 0;
    }

   public void InsertFirst(int no)
    {
        node newn  = new node();
        newn.data = no;
        newn.next = null;
        newn.prev = null;

        if((Head == null) && (Tail == null))
        {
            Head = newn;
            Tail = newn;
        }
        else
        {
            newn.next = Head;
            Head.prev = newn;
            Head = newn;
        }
       Head.prev = Tail;
       Tail.next = Head;
       Count++;
    }

 public void InsertLast(int no)
    {
        node newn  = new node();
        newn.data = no;
        newn.next = null;
        newn.prev = null;

        if((Head == null)&&(Tail==null))
        {
            Head = newn;
            Tail = newn;
        }
        else
        {
            Tail.next = newn;
            newn.prev = Tail;
            Tail = newn;
        }
        Tail.next = Head;
        Head.prev = Tail;
        Count++;
    }

public void InsertAtPos(int no, int pos)
    {
        if((pos < 1) || (pos > Count +1))
        {
            return;
        }
        if(pos ==1)
        {
            InsertFirst(no);
        }
        else if(pos == Count +1)
        {
            InsertLast(no);
        }
        else
        {
            node newn = new node();
            newn.data = no;
            newn.next = null;
            newn.prev = null;

            node temp = Head;

            for(int i = 1; i < pos-1; i++)
            {
                temp = temp.next;
            }
            newn.next = temp.next;
            temp.next.prev = newn;
            newn.prev = temp;
            temp.next = newn;
            Tail.next = Head;
            Count++;
        }
    }

 public void DeleteFirst()
    {
        if(Count == 0)
        {
            return;
        }
        else if(Count == 1)
        {
            Head = null;
            Tail = null;
        }
        else
        {
            Head = Head.next;
            Tail.next = null;
        }
        Tail.next = Head;
        Head.prev = Tail;
        Count--;
    }
 public void DeleteLast()
    {
        if(Count == 0)
        {
            return;
        }
        else if(Count == 1)
        {
            Head = null;
            Tail = null;
        }
        else
        {
            node temp = Head;

            while(temp.next != Tail)
            {
                temp = temp.next;
            }
            temp.next = null;
            Tail = temp;
        }
        Tail.next = Head;
        Head.prev = Tail;
        Count--;
    }

  public void DeleteAtPos(int pos)
    {
        if((pos < 1) || (pos > Count))
        {
            System.out.println("Invalid Position");
            return;
        }
        if(pos == 1)
        {
            DeleteFirst();
        }
        else if(pos == Count)
        {
            DeleteLast();
        }
        else
        {
            node Temp = Head;

            for(int i = 1; i < (pos-1); i++)
            {
                Temp = Temp.next;
            }
            Temp.next = Temp.next.next;
            Temp .next.prev = null;
            Temp.next.prev = Temp;
            Count--;
        }
    }

  public void Display()
    {
        node temp = Head;

        if((Head == null) && (Tail == null))
        {
            return;
        }
        do
        {
            System.out.print("|"+ temp.data +"|<=>");
            temp = temp.next;
        }while(temp != Tail.next);

        System.out.println(" ");
        }

    public int CountNode()
    {
        return Count;
    }
 }

 class Doubly_Circular_LL_JAVA
 {
   public static void main(String arg[])
    {
       DoublyCLL obj = new DoublyCLL();

        int iRet = 0;

         obj.InsertFirst(51);
         obj.InsertFirst(31);
         obj.InsertFirst(21);
         obj.InsertFirst(11);
         obj.InsertFirst(10);
         obj.InsertFirst(1);
         obj.Display();
         System.out.println("Number of elements are: "+ obj.CountNode());

          obj.InsertLast(71);
          obj.InsertLast(81);
          obj.InsertLast(101);
          obj.Display();
          System.out.println("Number of elements are: "+ obj.CountNode());

          obj.InsertAtPos(45,6);
          obj.InsertAtPos(65,8);
          obj.Display();
          System.out.println("Number of elements are: "+ obj.CountNode());

          obj.DeleteFirst();
          obj.DeleteLast();
          obj.Display();
          System.out.println("Number of elements are: "+ obj.CountNode());

          obj.DeleteAtPos(2);
          obj.DeleteAtPos(1);
          obj.DeleteAtPos(6);
          obj.Display();
          System.out.println("Number of elements are: "+ obj.CountNode());
     }
  }