// Queue Data Structure using Specific programming

import java.lang.*;
import java.util.*;

class node
{
   public int data;
   public node next;
}

class Queue
{
      public node Head;
      public int Count;

    public Queue()
    {
         Head = null;
        Count = 0;
    }

  public void Enqueue(int no)       //InsertLast()
    {
        node newn  = new node();
        newn.data = no;
        newn.next = null;

        if(Head == null)
        {
            Head = newn;
        }
        else
        {
            node temp = Head;

            while(temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newn;
        }
        Count++;
    }

   public void Dequeue()        // DeleteFirst()
    {
          int no;
         if(Count == 0)
        {
            System.out.println("Queue is Empty");
            return;
        }
            no = Head.data;
            node temp = Head;
            Head = Head.next;
            temp = null;

        Count--;
        System.out.println("Removed Element is: "+ no+"\n");

    }
  public void Display()
    {
         node temp = Head;

        System.out.println("Elements of linkedlist are: ");

        while(temp!=null)
        {
            System.out.print("|"+ temp.data +"|->");
            temp = temp.next;
        }
         System.out.println("NULL");

    }
    int CountNode()
    {
       return Count;
    }
}

class Queue_JAVA
{
    public static void main(String arg[])
    {
        Queue obj1 = new Queue();

     obj1.Enqueue(11);
     obj1.Enqueue(21);
     obj1.Enqueue(51);
     obj1.Enqueue(101);
     obj1.Display();
     System.out.println("Number of elements are: "+ obj1.CountNode());

     obj1.Dequeue();
      obj1.Dequeue();
      obj1.Dequeue();
      obj1.Display();
      System.out.println("Number of elements are: "+ obj1.CountNode());
      obj1.Dequeue();
      obj1.Dequeue();

    }
}