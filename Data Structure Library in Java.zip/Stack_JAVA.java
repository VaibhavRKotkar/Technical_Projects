// Stack data structure using specific programming in JAVA.

import java.lang.*;
import java.util.*;

class node
{
   public int data;
   public node next;    // reference concept
}

class Stack
{
     public node Head;
     public int Count;

    public Stack()
    {
        Head = null;
        Count = 0;
    }

 public void Push(int no)  //InsertFirst
    {
        node newn  = new node();
        newn.data = no;
        newn.next = null;

        if(Head == null)
        {
            Head = newn;
        }
        else
        {
            newn.next = Head;
            Head = newn;
        }
        Count++;
    }

 public void Pop()        // DeleteFirst()
    {
       int no;
       if(Count == 0)
        {
            System.out.println("Stack is Empty");
            return;
        }
            no = Head.data;
            node temp = Head;
            Head = Head.next;
            temp = null;

        Count--;
        System.out.println("Removed Element is: "+ no+"\n");

    }
  public void Display()
    {
         node temp = Head;

        System.out.println("Elements of linkedlist are: ");

        while(temp!=null)
        {
            System.out.print("|"+ temp.data +"|->");
            temp = temp.next;
        }
         System.out.println("NULL");

    }
    int CountNode()
    {
       return Count;
    }
}

class Stack_JAVA
{
    public static void main(String arg[])
    {
       Stack obj = new Stack();

       obj.Push(71);
       obj.Push(51);
       obj.Push(21);
       obj.Push(11);
       obj.Push(10);
       obj.Display();
       System.out.println("Number of elements are: "+ obj.CountNode());

       obj.Pop();
       obj.Pop();
       obj.Pop();
       obj.Pop();
       obj.Display();
       System.out.println("Number of elements are: "+ obj.CountNode());

       obj.Pop();
       obj.Pop();
       obj.Display();
       System.out.println("Number of elements are: "+ obj.CountNode());


    }

}
