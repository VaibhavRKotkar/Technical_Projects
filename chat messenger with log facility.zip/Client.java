import java.lang.*;
import java.net.*;
import java.io.*;
import java.io.FileWriter;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.format.DateTimeFormatter;

class Client
{
    public static void main(String arg[]) throws Exception
    {
        System.out.println("Client application is running...");
        String s1, s2;


        Socket s = new Socket("LocalHost", 1100);


           BufferedReader brK = new BufferedReader(new InputStreamReader(System.in));
           BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
           PrintStream ps = new PrintStream(s.getOutputStream());

            Date date = new Date() ;
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;

            File file = new File(dateFormat.format(date) + ".txt") ;
         System.out.print("Client: ");
         while(!(s1 = brK.readLine()).equals("exit"))
        {
            ps.println(s1);
            s2 = br.readLine();
            System.out.print("Server :"+s2);
            System.out.println();
            System.out.print("Client: ");
            try
            {
                 FileWriter output = new FileWriter(file,true);
                 output.write(java.time.Clock.systemUTC().instant() +"  Client: "+s1);
                 output.write("\n");
                 output.write(java.time.Clock.systemUTC().instant()+"  Server :"+s2);
                 output.write("\n");
                 output.close();
            }
             catch (Exception e) { e.getStackTrace(); }
        }
        s.close();
        br.close();
        brK.close();
        ps.close();
    }
}