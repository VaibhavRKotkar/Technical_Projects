import java.lang.*;
import java.net.*;
import java.io.*;
import java.io.FileWriter;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.format.DateTimeFormatter;

class Server
{
    public static void main(String arg[]) throws Exception
    {
        System.out.println("Server application is running.....");
        String s1, s2;

        ServerSocket ss =new ServerSocket(1100);
        Socket s = ss.accept();

        System.out.println("Connection Successful");
        BufferedReader brK = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        PrintStream ps = new PrintStream(s.getOutputStream());

          Date date = new Date() ;
          SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
          File file = new File(dateFormat.format(date) + ".txt") ;

       while((s1 = br.readLine())!= null)
        {
            System.out.print("Client : "+s1);
            System.out.println();
            System.out.print("Server: ");
            s2 = brK.readLine();
            ps.println(s2);

            try
            {
                 FileWriter output = new FileWriter(file,true);
                 output.write(java.time.Clock.systemUTC().instant() +"  Client: "+s1);
                 output.write("\n");
                 output.write(java.time.Clock.systemUTC().instant()+"  Server :"+s2);
                 output.write("\n");
                 output.close();
            }
             catch (Exception e) { e.getStackTrace(); }
        }
         s.close();
         ss.close();
         br.close();
         brK.close();
         ps.close();
    }
}